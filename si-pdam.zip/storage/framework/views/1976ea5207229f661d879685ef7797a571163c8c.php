<?php $__env->startSection('title', 'Berita'); ?>

<style>
    .crop-text-2 {
        -webkit-line-clamp: 8;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-box-orient: vertical;
    }
</style>
<?php $__env->startSection('content'); ?>
<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
    <div class="container">

        <div class="d-flex justify-content-between align-items-center">
            <h2>Berita</h2>
            <ol>
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li>Berita</li>
            </ol>
        </div>

    </div>
</section><!-- End Breadcrumbs -->
<!-- ======= Blog Section ======= -->
<section id="blog" class="blog">
    <div class="container" data-aos="fade-up">
        <div class="section-title">
            <h2>News</h2>
            <p>Berita</p>
        </div>
        <div class="row">
            <div class="col-lg-8">
                <div class="row">
                    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 entries">
                        <article class="entry">
                            <div class="entry-img">
                                <img src="<?php echo e(asset('galeri/informasi/'. $data->foto)); ?>" alt="" class="img-fluid">
                            </div>
                            <h2 class="entry-title">
                                <a href="<?php echo e(url('detail-berita/'. $data->id)); ?>"><?php echo e($data->judul); ?></a>
                            </h2>
                            <div class="entry-meta">
                                <ul>
                                    <li class="d-flex align-items-center"><i class="bi bi-person"></i> <a href="blog-single.html">Administrator</a></li>
                                    <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <a href="blog-single.html"><time datetime="<?php echo e($data->created_at); ?>"><?php echo e($data->created_at); ?></time></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="entry-content">
                                <p class="crop-text-2">
                                    <?php echo e($data->isi_informasi); ?>

                                </p>
                                <div class="read-more">
                                    <a href="<?php echo e(url('detail-berita/'. $data->id)); ?>">Read More</a>
                                </div>
                            </div>
                        </article>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- <div class="blog-pagination">
                    <ul class="justify-content-center">
                        <li><a href="#">1</a></li>
                        <li class="active"><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                    </ul>
                </div> -->
            </div>


            <div class="col-lg-4">
                <div class="sidebar">
                    <!-- <h3 class="sidebar-title">Search</h3>
                    <div class="sidebar-item search-form">
                        <form action="">
                            <input type="text">
                            <button type="submit"><i class="bi bi-search"></i></button>
                        </form>
                    </div>End sidebar search formn -->

                    <h3 class="sidebar-title">Berita Terkini</h3>
                    <div class="sidebar-item recent-posts">
                        <?php $__currentLoopData = $beritabaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post-item clearfix">
                            <img src="<?php echo e(asset('galeri/informasi/'. $data->foto)); ?>" alt="" class="img-thumbnail">
                            <h4><a href="<?php echo e(url('detail-berita/'. $data->id)); ?>"><?php echo e($data->judul); ?></a></h4>
                            <time datetime="<?php echo e($data->created_at); ?>"><?php echo e($data->created_at); ?></time>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div><!-- End sidebar recent posts-->
                </div><!-- End sidebar -->

            </div><!-- End blog sidebar -->
        </div>
    </div>
</section>
<!-- End blog entry -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tama/Documents/si-pdam/resources/views/user/berita.blade.php ENDPATH**/ ?>