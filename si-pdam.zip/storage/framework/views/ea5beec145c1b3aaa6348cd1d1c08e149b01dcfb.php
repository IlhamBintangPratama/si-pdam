<head>
    <title>Surat Pengaduan</title>
    <meta charset="utf-8">
</head>
<body>
    
    <div class="table-responsive">
        <div>
            <h3 style="text-align: center; padding-bottom: 2%">Surat Pengaduan</h3>
            <span style="float: right; text-align: left; margin-bottom: 5em;">Brebes, <?php echo e($pengaduan->created_at->format('d-m-Y')); ?></span>
            
        </div>
        <p>Saya yang bertanda tangan di bawah ini :</p>
        <table class="table table-bordered">
            <tbody>
                <tr>
                    <td>ID Pengaduan</td>
                    <td style="letter-spacing: 10px; padding-left: 30px">:</td>
                    <td><?php echo e($pengaduan->id_pelanggan); ?></td>
                </tr>
                <tr>
                    <td>Nama Lengkap</td>
                    <td style="letter-spacing: 10px; padding-left: 30px">:</td>
                    <td><?php echo e($pengaduan->nama); ?></td>
                </tr>
                <tr>
                    <td>Alamat</td>
                    <td style="letter-spacing: 10px; padding-left: 30px">:</td>
                    <td><?php echo e($pengaduan->alamat); ?></td>
                </tr>
                
                
            </tbody>
        </table>
        <div style="margin-top: 20px">
        <?php
            $image = public_path('galeri/pengaduan/'.$pengaduan->foto); 
        ?>
        <img src="data:image/png;base64,
            <?php echo base64_encode(file_get_contents($image)); ?>" width="160px" alt="">
        </div>
        <div>
            <p style="width: 20%">Isi Keluhan</p>
            <p><?php echo e($pengaduan->keluhan); ?></p>
        </div>
    </div>
</body><?php /**PATH /home/tama/Documents/si-pdam/resources/views/menu-admin/pengaduan/cetak.blade.php ENDPATH**/ ?>