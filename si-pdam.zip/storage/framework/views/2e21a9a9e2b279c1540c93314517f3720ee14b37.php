<!DOCTYPE html>
<html lang="en">
<!-- header -->
<?php echo $__env->make('layouts-user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>

    <!-- ======= Header ======= -->
    <!-- navbar -->
    <?php echo $__env->make('layouts-user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Header -->

    <main id="main">

        <!-- content -->
        <?php echo $__env->yieldContent('content'); ?>

    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <?php echo $__env->make('layouts-user.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tama/Documents/si-pdam/resources/views/layouts-user/main.blade.php ENDPATH**/ ?>