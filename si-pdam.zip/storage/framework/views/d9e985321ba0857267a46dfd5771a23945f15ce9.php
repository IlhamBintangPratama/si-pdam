<div class="table-responsive">
    <table class="table table-bordered">
        <tbody>
            <tr>
                <td style="width: 20%">ID Pengaduan</td>
                <td><?php echo e($pengaduan->id_pelanggan); ?></td>
            </tr>
            <tr>
                <td style="width: 20%">Nama Lengkap</td>
                <td><?php echo e($pengaduan->nama); ?></td>
            </tr>
            <tr>
                <td style="width: 20%">Alamat</td>
                <td><?php echo e($pengaduan->alamat); ?></td>
            </tr>
            <tr>
                <td style="width: 20%">Foto</td>
                <td><img src="/galeri/pengaduan/<?php echo e($pengaduan->foto); ?>" width="150px"></td>
            </tr>
            <tr>
                <td style="width: 20%">Keluhan</td>
                <td><?php echo e($pengaduan->keluhan); ?></td>
            </tr>
            
        </tbody>
    </table>
</div><?php /**PATH /home/tama/Documents/si-pdam/resources/views/menu-admin/pengaduan/testing.blade.php ENDPATH**/ ?>