<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Tambah Data Tagihan Pelanggan</h1>
        <br>

        <!-- DataTales Example -->
        
        <div class="card shadow">
            <div class="card-header py-4">
                
                

                <form method="post" action="<?php echo e(url('menu-admin/tagihan')); ?>" name="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    
                        
                        <div class="mb-3">
                            <label for="no_rekening_air">No Pelanggan</label>
                            
                            <select name="no_rekening_air" id="no_rekening_air" class="form-control <?php $__errorArgs = ['no_rekening_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            is-invalid
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" onchange="getData(this)">
                                <option value="" selected disabled>- pilih -</option>
                                <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <option value="<?php echo e($data->no_rekening_air); ?>"><?php echo e($data->no_rekening_air); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['no_rekening_air'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          
                        </div>
                        <div class="mb-3">
                            <label for="nama">Nama</label>
                            <input class="form-control" id="nama" name="nama" type="text"  placeholder="Masukan nama pelanggan" hidden>
                            <input class="form-control" id="nama-1" name="nama-1" type="text"  placeholder="Masukan nama pelanggan" disabled>
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="alamat">Alamat</label>
                            <input class="form-control" name="alamat" id="alamat" type="text"  placeholder="Masukan alamat" hidden>
                            <input class="form-control" name="alamat-1" id="alamat-1" type="text"  placeholder="Masukan alamat" disabled>
                                <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="jumlah_tagihan">Jumlah Tagihan</label>
                            <input class="form-control <?php $__errorArgs = ['jumlah_tagihan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            is-invalid
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jumlah_tagihan" value="<?php echo e(old('jumlah_tagihan')); ?>" name="jumlah_tagihan" type="number" placeholder="Masukan jumlah tagihan">
                            <?php $__errorArgs = ['jumlah_tagihan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div style="margin-top: 17%;">
                            <button type="submit" class="btn btn-primary w-100 mb-2">Simpan</button>
                            <button type="button" id="back" class="btn btn-secondary w-100">Kembali</button>
                        </div>
                    
                </form>
                <script>
                    document.getElementById('back').onclick = function(){
                        location.href = "<?php echo e(url('menu-admin/tagihan')); ?>";
                    }
                    function getData(pelanggan){
                        $.ajax({
                            url : 'listdata/' + $('#no_rekening_air').val(),
                            type : 'GET',
                            dataType : 'json',
                            success : function(data){
                                let newData = data.find((item) => item.no_rekening_air == pelanggan.value)

                                $('#nama').val(newData.nama).show(),
                                $('#nama-1').val(newData.nama).show(),
                                $('#alamat').val(newData.alamat).show(),
                                $('#alamat-1').val(newData.alamat).show()
                            }
                        })
                    }
                </script>

            </div>
        </div>

    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tama/Documents/si-pdam/resources/views/menu-admin/tagihan/create.blade.php ENDPATH**/ ?>