<?php $__env->startSection('title', 'Pasang Baru'); ?>

<?php $__env->startSection('content'); ?>
<!-- ======= Breadcrumbs ======= -->
<section id="breadcrumbs" class="breadcrumbs">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center">
            <h2>Pasang Baru</h2>
            <ol>
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li>Pasang Baru</li>
            </ol>
        </div>
    </div>
</section><!-- End Breadcrumbs -->
<section id="faq" class="faq">
    <div class="container">

        <div class="section-title">
            <h2>Pasang Baru</h2>
            <p>Cara Pemasangan PDAM Baru</p>
        </div>

        <div class="row faq-item d-flex align-items-stretch">
            <div class="col-lg-5">
                <i class="bx bx-help-circle"></i>
                <h4>Persyaratan Pemasangan PDAM Baru ?</h4>
            </div>
            <div class="col-lg-7">
                <p>
                    <?php echo $pasang->persyaratan; ?>

                </p>
            </div>
        </div><!-- End F.A.Q Item-->

        <div class="row faq-item d-flex align-items-stretch">
            <div class="col-lg-5">
                <i class="bx bx-help-circle"></i>
                <h4>Biaya Pemasangan PDAM Baru ?</h4>
            </div>
            <div class="col-lg-7">
                <p>
                    <?php echo $pasang->harga_pasang; ?>

                </p>
            </div>
        </div><!-- End F.A.Q Item-->

    </div>
</section><!-- End Frequently Asked Questions Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts-user.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tama/Documents/si-pdam/resources/views/user/pasang.blade.php ENDPATH**/ ?>