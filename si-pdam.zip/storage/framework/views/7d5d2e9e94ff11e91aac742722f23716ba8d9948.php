<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <?php if($message = Session::get('created')): ?>
    <div class="alert alert-success ml-4 mr-4" role="alert">
        <?php echo e($message); ?>

    </div>
    <?php endif; ?>
    <?php if(isset($updated)): ?>
    <div class="alert alert-success ml-4 mr-4" role="alert">
        <?php echo e($updated ?? ""); ?>

    </div>
    <?php endif; ?>
    <?php if($message = Session::get('deleted')): ?>
    <div class="alert alert-success ml-4 mr-4" role="alert">
        <?php echo e($message); ?>

    </div>
    <?php endif; ?>
    <?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger ml-4 mr-4" role="alert">
        <?php echo e($message); ?>

    </div>
    <?php endif; ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Pasang Baru</h1>
        <br>

        <!-- DataTales Example -->
        
        <div class="card shadow">
            <div class="card-header py-4">
                
                

                <form method="post" action="<?php echo e(url('menu-admin/pasangbaru/'.$pasang_baru->id.'/update')); ?>" name="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    
                        
                        <div class="mb-3">
                            <label for="persyaratan">Persyaratan</label>
                            <textarea class="ckeditor form-control <?php $__errorArgs = ['persyaratan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                is-invalid
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="persyaratan" value="<?php echo e(old('persyaratan')); ?>" name="persyaratan" type="text"  placeholder="Masukan persyaratan">
                                <?php echo e(old('name', $pasang_baru->persyaratan)); ?>

                            </textarea>
                            <?php $__errorArgs = ['persyaratan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                        </div>
                        <div class="mb-3">
                            <label for="harga_pasang">Harga Pasang</label>
                            <textarea class="ckeditor form-control <?php $__errorArgs = ['harga_pasang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                is-invalid
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="harga_pasang" value="<?php echo e(old('harga_pasang')); ?>" name="harga_pasang" type="text"  placeholder="Masukan harga pasang">
                                <?php echo e(old('name', $pasang_baru->harga_pasang)); ?>

                            </textarea>
                                
                            <?php $__errorArgs = ['harga_pasang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          
                        </div>
                        <div>
                            <button type="submit" class="btn btn-primary w-100 mb-2">Publish</button>
                        </div>
                    
                </form>
                <script src="<?php echo e(asset('js')); ?>/jquery.min.js"></script>
                <script src="//cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
                <script type="text/javascript">
                    $(document).ready(function () {
                        $('.ckeditor').ckeditor();
                    });
                    setTimeout(function() {
                    $('.alert').fadeOut('slow');}, 3000
                    );
                </script>
            </div>
        </div>

    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tama/Documents/si-pdam/resources/views/menu-admin/pasang_baru/edit.blade.php ENDPATH**/ ?>