<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <link rel="stylesheet" href="<?php echo e(asset('vselect')); ?>/virtual-select.min.css">
    <?php if($message = Session::get('created')): ?>
    <div class="alert alert-success ml-4 mr-4" role="alert">
        <?php echo e($message); ?>

    </div>
    <?php endif; ?>
    <div class="container-fluid">

        <!-- Page Heading -->
        <h1 class="h3 mb-2 text-gray-800">Broadcast</h1>
        <br>

        <!-- DataTales Example -->
        
        <div class="card shadow">
            <div class="card-header py-4">
                
                

                <form method="post" action="<?php echo e(url('/menu-admin/broadcast/broadcastWhatsapp')); ?>" name="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    
                        
                        <style>
                            .select{
                                max-width: 100%;
                                ;
                            }
                        </style>
                        <div class="mb-3">
                            <label for="no_telp">No Telp</label>
                            <select class="select" multiple data-search="true" data-silent-initial-value-set="false" id="selectpicker" name="no_telp">
                                <option value="" selected disabled>- pilih -</option>
                                <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <option type="checkbox" value="<?php echo e($data->no_telp); ?>"><?php echo e($data->no_telp); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          
                        </div>
                        <div class="mb-3">
                            <label for="pesan">Pesan Broadcast</label>
                            <textarea class="form-control <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                is-invalid
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pesan" name="pesan" type="text" style="resize: none; white-space: pre-line;" rows="5" cols="20">
                                
                            </textarea>
                                <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div style="margin-top: 22%;">
                            <button type="submit" class="btn btn-primary w-100 mb-2">Kirim Pesan Broadcast</button>
                        </div>
                    
                </form>
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
                <script src="<?php echo e(asset('vselect')); ?>/virtual-select.min.js"></script>
                <script>
                    
                    setTimeout(function() {
                    $('.alert').fadeOut('slow');}, 3000
                    );
                    VirtualSelect.init({
                        ele: '#selectpicker'
                    })
                </script>

            </div>
        </div>

    </div>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tama/Documents/si-pdam/resources/views/menu-admin/broadcast/broadcast.blade.php ENDPATH**/ ?>